import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import "./Register.css";

const Register = () => {
  const [user, setUser] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [error, setError] = useState(null);
  const navigate = useNavigate();

  const handleSubmit = (e) => {
    e.preventDefault();

    if (password !== confirmPassword) {
      setError("Passwords do not match.");
      return;
    }
    navigate("/login");
  };

  return (
    <div className="main-register">
      <div className="register">
        <form onSubmit={handleSubmit}>
          <div>
            <h1>สมัครสมาชิก</h1>
            <label>ชื่อ:</label>
            <input type="text" />
          </div>
          <div>
            <label>นามสกุล:</label>
            <input type="text" />
          </div>
          <div>
            <label>เบอร์โทรศัพท์:</label>
            <input type="text" />
          </div>
          <div>
            <label>เลขทะเบียนรถ:</label>
            <input type="text" />
          </div>
          <div>
            <label>User:</label>
            <input
              type="text"
              value={user}
              onChange={(e) => setUser(e.target.value)}
            />
          </div>
          <div>
            <label>Password:</label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
          </div>
          <div>
            <label>Confirm Password:</label>
            <input
              type="password"
              value={confirmPassword}
              onChange={(e) => setConfirmPassword(e.target.value)}
            />
          </div>
          {error && <div>{error}</div>}
          <button type="submit">Register</button>
        </form>
      </div>
    </div>
  );
};

export default Register;
