import { useNavigate } from "react-router-dom";
import axios from "axios";
import { useEffect } from "react";
import { useAuth } from "./context/AuthContext";

function Verify() {
  const navigate = useNavigate();
  const { setUser } = useAuth(); // Get the login function from context

  useEffect(() => {
    const token = localStorage.getItem("jwt");
    if (token) {
      axios
        .get("http://localhost:5000/api/verify-token", {
          headers: {
            authorization: token,
          },
        })
        .then((response) => {
          const userData = {
            id:response.data.user.Officer_ID,
            fname: response.data.user.Officer_Fname,
            lname: response.data.user.Officer_Lname,
            username: response.data.user.Officer_Username,
            password: response.data.user.Officer_Password,
            tel: response.data.user.Officer_Tel,
            role: response.data.user.role,
          };
          setUser(userData); // Set user data in AuthContext
          navigate("/"); // Redirect to home after login
          console.log(userData.name)
        })
        .catch((error) => {
          console.error("Token verification failed", error);
          localStorage.removeItem("jwt"); // Clear token on error
          navigate("/login"); // Redirect to login on error
        });
    } else {
      navigate("/login"); // Redirect to login if no token
    }
  }, [navigate,setUser]);
  

  return null; // Optional: You can return a loading spinner or message while verifying
}

export default Verify;
