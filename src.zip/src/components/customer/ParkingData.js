import React from 'react';

function ParkingData() {
  return <div><h1>ข้อมูลการจอด</h1></div>;
}

export default ParkingData;