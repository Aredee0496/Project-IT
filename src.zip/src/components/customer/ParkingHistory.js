import React from 'react';

function ParkingHistory() {
  return <div><h1>ประวัติการจอด</h1></div>;
}

export default ParkingHistory;