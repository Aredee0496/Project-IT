import React from 'react';

function EditProfile() {
  return <div><h1>แก้ไขข้อมูล</h1></div>;
}

export default EditProfile;