import React from 'react';

function RequestShuttle() {
  return <div><h1>เรียกรถรับส่ง</h1></div>;
}

export default RequestShuttle;