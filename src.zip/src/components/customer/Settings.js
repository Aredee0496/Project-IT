import React from 'react';

function Settings() {
  return <div><h1>ตั้งค่า</h1></div>;
}

export default Settings;