import React from 'react';

function Booking() {
  return <div><h1>หน้าทำรายการจอง</h1></div>;
}

export default Booking;