import React, { useEffect } from "react";
import { useAuth } from "../../context/AuthContext";
import { useNavigate } from "react-router-dom";

function Booking() {
  const { user } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (!user) {
      navigate("/verify"); 
    }else{
      console.log(user)
    }
  }, [user, navigate]);
  console.log("eiei", user);

  return (
    <div>
      <h1>หน้าการจองลูกค้า</h1>
      <div>
        <p>iD: {user?.id}</p>
        <p>ยินดีต้อนรับคุณ: {user?.fname}</p>
        <p>บทบาท: {user?.role}</p>
      </div>
    </div>
  );
}

export default Booking;