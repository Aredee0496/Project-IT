import React, { useState } from 'react';
import { NavLink } from 'react-router-dom';
import './Sidebar.css'; // Assuming you have a CSS file for styling

const Sidebar = () => {
  const [showReportsSubmenu, setShowReportsSubmenu] = useState(false);
  const [showDataManagementSubmenu, setShowDataManagementSubmenu] = useState(false);

  const toggleReportsSubmenu = () => {
    setShowReportsSubmenu(!showReportsSubmenu);
  };

  const toggleDataManagementSubmenu = () => {
    setShowDataManagementSubmenu(!showDataManagementSubmenu);
  };

  return (
    <nav className="sidebar">
      <ul>
        <li>
          <NavLink to="/" exact activeClassName="active">Home</NavLink>
        </li>
        <li>
          <NavLink to="/bookings" activeClassName="active">Bookings</NavLink>
        </li>
        <li>
          <NavLink to="/parking" activeClassName="active">Parking</NavLink>
        </li>
        <li>
          <NavLink to="/shuttle" activeClassName="active">Shuttle</NavLink>
        </li>
        <li>
          <div className="menu-title" onClick={toggleReportsSubmenu}>Reports</div>
          {showReportsSubmenu && (
            <ul className="submenu">
              <li>
                <NavLink to="/reports/revenue" activeClassName="active">Revenue</NavLink>
              </li>
              <li>
                <NavLink to="/reports/usage" activeClassName="active">Usage Statistics</NavLink>
              </li>
            </ul>
          )}
        </li>
        <li>
          <div className="menu-title" onClick={toggleDataManagementSubmenu}>Data Management</div>
          {showDataManagementSubmenu && (
            <ul className="submenu">
              <li>
                <NavLink to="/data-management/parkinglist" activeClassName="active">ข้อมูลที่จอดรถ</NavLink>
              </li>
              <li>
                <NavLink to="/data-management/employee" activeClassName="active">ข้อมูลพนักงาน</NavLink>
              </li>
              <li>
                <NavLink to="/data-management/customer" activeClassName="active">ข้อมูลลูกค้า</NavLink>
              </li>
              <li>
                <NavLink to="/data-management/shuttle" activeClassName="active">ข้อมูลรถรับส่ง</NavLink>
              </li>
            </ul>
          )}
        </li>
      </ul>
    </nav>
  );
}

export default Sidebar;
