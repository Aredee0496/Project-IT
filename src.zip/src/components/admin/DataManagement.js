import React from 'react';

function DataManagement() {
  return <div><h1>หน้าจัดการข้อมูล</h1></div>;
}

export default DataManagement;