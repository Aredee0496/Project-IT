import React from 'react';

function Shuttle() {
  return <div><h1>หน้าเรีกรถ</h1></div>;
}

export default Shuttle;