import React, { useState, useEffect } from "react";
import "./Parking.css";
import axios from "axios";
import { Select, Card } from "antd"; 

const { Option } = Select; 

function Parking() {
  const [parkingData, setParkingData] = useState([]);
  const [statusFilter, setStatusFilter] = useState("ทั้งหมด");
  const [typeFilter, setTypeFilter] = useState("ทั้งหมด");
  const [currentTime, setCurrentTime] = useState(new Date());

  useEffect(() => {
    const fetchData = async () => {
      try {
        const parkingResponse = await axios.get(
          "http://localhost:5000/api/parkings"
        );
        setParkingData(parkingResponse.data);
      } catch (error) {
        console.error("Error fetching parking data:", error);
      }
    };

    fetchData();

    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  const getStatusClass = (status) => {
    switch (status) {
      case "ว่าง":
        return "available";
      case "ไม่ว่าง":
        return "occupied";
      case "จอง":
        return "reserved";
      default:
        return "";
    }
  };

  const filteredParkingData = parkingData.filter(
    (spot) =>
      (statusFilter === "ทั้งหมด" || spot.PStatus_name === statusFilter) &&
      (typeFilter === "ทั้งหมด" || spot.Type_name === typeFilter)
  );

  return (
    <div>
      <div className="filter-group">
        <div className="filter-section">
          <h2>สถานะ</h2>
          <Select
            value={statusFilter}
            onChange={(value) => setStatusFilter(value)}
            style={{ width: 120 }}
          >
            <Option value="ทั้งหมด">ทั้งหมด</Option>
            <Option value="ว่าง">ว่าง</Option>
            <Option value="ไม่ว่าง">ไม่ว่าง</Option>
            <Option value="จอง">จอง</Option>
          </Select>
        </div>
        
        <div className="legend top-right">
          <div className="legend-item">
            <span className="legend-color available"></span> ว่าง
          </div>
          <div className="legend-item">
            <span className="legend-color occupied"></span> ไม่ว่าง
          </div>
          <div className="legend-item">
            <span className="legend-color reserved"></span> จอง
          </div>
          
          <Card style={{ marginTop: 16, textAlign: "center" }}>
            <div>{currentTime.toLocaleDateString("th-TH")}</div>
            <div>
              {currentTime.toLocaleTimeString("th-TH", {
                hour: "2-digit",
                minute: "2-digit",
                second: "2-digit",
                hour12: false,
              })}
            </div>
          </Card>
        </div>

        <div className="filter-section">
          <h2>ประเภท</h2>
          <div className="button-group">
            <button
              className={typeFilter === "ทั้งหมด" ? "active" : ""}
              onClick={() => setTypeFilter("ทั้งหมด")}
            >
              ทั้งหมด
            </button>
            <button
              className={typeFilter === "ในร่ม" ? "active" : ""}
              onClick={() => setTypeFilter("ในร่ม")}
            >
              ในร่ม
            </button>
            <button
              className={typeFilter === "กลางแจ้ง" ? "active" : ""}
              onClick={() => setTypeFilter("กลางแจ้ง")}
            >
              กลางแจ้ง
            </button>
          </div>
        </div>
      </div>

      <div className="parking-grid">
        {filteredParkingData.map((spot) => (
          <div
            key={spot.Parking_ID}
            className={`parking-spot ${getStatusClass(spot.PStatus_name)}`}
          >
            {spot.Parking_ID}
          </div>
        ))}
      </div>
    </div>
  );
}

export default Parking;
