import React, { useState } from 'react';
import "./Parking.css";

function Parking() {
  const [parkingType, setParkingType] = useState('indoor');

  const indoorParkingSpots = [
    { id: 'A001', status: 'ว่าง' },
    { id: 'A002', status: 'จอง' },
    { id: 'A003', status: 'ไม่ว่าง' },
    // เพิ่มที่จอดรถตามต้องการ
  ];

  const outdoorParkingSpots = [
    { id: 'B001', status: 'จอง' },
    { id: 'B002', status: 'ไม่ว่าง' },
    { id: 'B003', status: 'จอง' },
    // เพิ่มที่จอดรถตามต้องการ
  ];

  const toggleParkingType = () => {
    setParkingType(prevType => prevType === 'indoor' ? 'outdoor' : 'indoor');
  };

  return (
    <div className="content-component">
      <h1>ดูที่จอดรถน่ะจ๊ะ</h1>
      <button onClick={toggleParkingType}>
        {parkingType === 'indoor' ? 'ที่จอดรถในร่ม' : 'ที่จอดรถกลางแจ้ง'}
      </button>
      <div className="parking-spots">
        {/* แสดงที่จอดรถตามประเภทที่เลือก */}
        {parkingType === 'indoor' ? (
          indoorParkingSpots.map(spot => (
            <div key={spot.id} className={`parking-spot ${spot.status === 'ว่าง' ? 'green' : spot.status === 'ไม่ว่าง' ? 'red' : 'yellow'}`}>
              {spot.id} 
            </div>
          ))
        ) : (
          outdoorParkingSpots.map(spot => (
            <div key={spot.id} className={`parking-spot ${spot.status === 'ว่าง' ? 'green' : spot.status === 'ไม่ว่าง' ? 'red' : 'yellow'}`}>
              {spot.id} 
            </div>
          ))
        )}
      </div>
    </div>
  );
}

export default Parking;
