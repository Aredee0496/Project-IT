import React, { useState, useEffect } from "react";
import "./Parking.css";
import axios from "axios";

function Parking() {
  const [parkingData, setParkingData] = useState([]);
  const [statusFilter, setStatusFilter] = useState("ทั้งหมด");
  const [typeFilter, setTypeFilter] = useState("ทั้งหมด");

  useEffect(() => {
    const fetchData = async () => {
      try {
        // Fetch parking data
        const parkingResponse = await axios.get("http://localhost:5000/api/parkings");
        setParkingData(parkingResponse.data);
      } catch (error) {
        console.error("Error fetching parking data:", error);
      }
    };

    fetchData();
  }, []);

  const getStatusClass = (status) => {
    switch (status) {
      case "ว่าง":
        return "available";
      case "ไม่ว่าง":
        return "occupied";
      case "จอง":
        return "reserved";
      default:
        return "";
    }
  };

  // Filter parking data based on status and type
  const filteredParkingData = parkingData
    .filter((spot) =>
      (statusFilter === "ทั้งหมด" || spot.PStatus_name === statusFilter) &&
      (typeFilter === "ทั้งหมด" || spot.Type_name === typeFilter)
    );

  return (
    <div>
      <h1>ข้อมูลที่จอดรถ</h1>
      <div className="filter-group">
        <div className="filter-section">
          <h2>สถานะ</h2>
          <select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)}>
            <option value="ทั้งหมด">ทั้งหมด</option>
            <option value="ว่าง">ว่าง</option>
            <option value="ไม่ว่าง">ไม่ว่าง</option>
            <option value="จอง">จอง</option>
          </select>
        </div>
        <div className="filter-section">
          <h2>ประเภท</h2>
          <div className="button-group">
            <button
              className={typeFilter === "ทั้งหมด" ? "active" : ""}
              onClick={() => setTypeFilter("ทั้งหมด")}
            >
              ทั้งหมด
            </button>
            <button
              className={typeFilter === "ในร่ม" ? "active" : ""}
              onClick={() => setTypeFilter("ในร่ม")}
            >
              ในร่ม
            </button>
            <button
              className={typeFilter === "กลางแจ้ง" ? "active" : ""}
              onClick={() => setTypeFilter("กลางแจ้ง")}
            >
              กลางแจ้ง
            </button>
          </div>
        </div>
      </div>
      <div className="parking-grid">
        {filteredParkingData.map((spot) => (
          <div key={spot.Parking_ID} className={`parking-spot ${getStatusClass(spot.PStatus_name)}`}>
            {spot.Parking_ID}
          </div>
        ))}
      </div>
    </div>
  );
}

export default Parking;
