import React from 'react';

function EmployeeData() {
  return <div><h1>ข้อมูลพนักงาน</h1></div>;
}

export default EmployeeData;
