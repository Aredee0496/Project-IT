import React from 'react';

function ParkingList() {
  return <div><h1>ข้อมูลที่จอดรถ</h1></div>;
}

export default ParkingList;
