import React, { useEffect, useState } from 'react';
import axios from 'axios';
import './ParkingList.css';

function ParkingList() {
  const [parkings, setParkings] = useState([]);
  const [error, setError] = useState(null);
  const [types, setTypes] = useState([]);
  const [newParking, setNewParking] = useState({ Type_ID: '', quantity: 1 });
  const [editPrice, setEditPrice] = useState({ Type_ID: '', newPriceHour: '', newPriceDay: '' });
  const [successMessage, setSuccessMessage] = useState('');
  const [showAddForm, setShowAddForm] = useState(false); 
  const [showEditPriceForm, setShowEditPriceForm] = useState(false); 

  useEffect(() => {
    const fetchParkings = async () => {
      try {
        const response = await axios.get('http://localhost:5000/api/parkings');
        setParkings(response.data);
      } catch (error) {
        console.error('Error fetching parkings:', error);
        setError('Failed to fetch data. Please try again later.');
      }
    };

    const fetchTypes = async () => {
      try {
        const response = await axios.get('http://localhost:5000/api/types'); 
        setTypes(response.data);
      } catch (error) {
        console.error('Error fetching types:', error);
        setError('Failed to fetch types. Please try again later.');
      }
    };

    fetchParkings();
    fetchTypes();
  }, []);

  const handleDelete = async (id) => {
    if (window.confirm('Are you sure you want to delete this parking spot?')) {
      try {
        await axios.delete(`http://localhost:5000/api/parkings/${id}`);
        setParkings(parkings.filter(parking => parking.Parking_ID !== id));
      } catch (error) {
        console.error('Error deleting parking:', error);
        setError('Failed to delete data. Please try again later.');
      }
    }
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setNewParking((prev) => ({ ...prev, [name]: value }));
  };

  const handleAddParking = async (e) => {
    e.preventDefault();
    try {
      const newParkings = [];
      for (let i = 0; i < newParking.quantity; i++) {
        const response = await axios.post('http://localhost:5000/api/parkings', {
          Type_ID: newParking.Type_ID
        });
        newParkings.push(response.data);
      }
      setParkings([...parkings, ...newParkings]);
      setSuccessMessage('Parking spots added successfully!');
      setNewParking({ Type_ID: '', quantity: 1 });
    } catch (error) {
      console.error('Error adding parking:', error);
      setError('Failed to add data. Please try again later.');
    } finally {
      setTimeout(() => setSuccessMessage(''), 3000);
    }
  };

  const handleEditPriceChange = (e) => {
    const { name, value } = e.target;
    setEditPrice((prev) => ({ ...prev, [name]: value }));
  };

  const handleEditPrice = async (e) => {
    e.preventDefault();
    try {
      await axios.put(`http://localhost:5000/api/types/${editPrice.Type_ID}`, {
        Price_Hour: editPrice.newPriceHour,
        Price_Day: editPrice.newPriceDay
      });

      setTypes(types.map(type => type.Type_ID === editPrice.Type_ID ? { ...type, Price_Hour: editPrice.newPriceHour, Price_Day: editPrice.newPriceDay } : type));
      setSuccessMessage('Prices updated successfully!');
      setEditPrice({ Type_ID: '', newPriceHour: '', newPriceDay: '' });
    } catch (error) {
      console.error('Error updating prices:', error);
      setError('Failed to update prices. Please try again later.');
    } finally {
      setTimeout(() => setSuccessMessage(''), 3000);
    }
  };

  return (
    <div>
      <h1>ข้อมูลที่จอดรถ</h1>
      {error && <p>{error}</p>}
      {successMessage && <p>{successMessage}</p>}

      <button onClick={() => setShowAddForm(!showAddForm)}>
        {showAddForm ? 'Hide Add Parking Form' : 'Show Add Parking Form'}
      </button>

      {showAddForm && (
        <form onSubmit={handleAddParking}>
          <div>
            <label htmlFor="Type_ID">Type:</label>
            <select
              id="Type_ID"
              name="Type_ID"
              value={newParking.Type_ID}
              onChange={handleChange}
              required
            >
              <option value="">Select Type</option>
              {types.map((type) => (
                <option key={type.Type_ID} value={type.Type_ID}>
                  {type.Type_name}
                </option>
              ))}
            </select>
          </div>
          <div>
            <label htmlFor="quantity">Quantity:</label>
            <input
              type="number"
              id="quantity"
              name="quantity"
              min="1"
              value={newParking.quantity}
              onChange={handleChange}
              required
            />
          </div>
          <button type="submit">Add Parking</button>
        </form>
      )}

      <button onClick={() => setShowEditPriceForm(!showEditPriceForm)}>
        {showEditPriceForm ? 'Hide Edit Price Form' : 'Show Edit Price Form'}
      </button>

      {showEditPriceForm && (
        <form onSubmit={handleEditPrice}>
          <div>
            <label htmlFor="editType_ID">Type:</label>
            <select
              id="editType_ID"
              name="Type_ID"
              value={editPrice.Type_ID}
              onChange={handleEditPriceChange}
              required
            >
              <option value="">Select Type</option>
              {types.map((type) => (
                <option key={type.Type_ID} value={type.Type_ID}>
                  {type.Type_name}
                </option>
              ))}
            </select>
          </div>
          <div>
            <label htmlFor="newPriceHour">New Price per Hour:</label>
            <input
              type="number"
              id="newPriceHour"
              name="newPriceHour"
              min="0"
              value={editPrice.newPriceHour}
              onChange={handleEditPriceChange}
              required
            />
          </div>
          <div>
            <label htmlFor="newPriceDay">New Price per Day:</label>
            <input
              type="number"
              id="newPriceDay"
              name="newPriceDay"
              min="0"
              value={editPrice.newPriceDay}
              onChange={handleEditPriceChange}
              required
            />
          </div>
          <button type="submit">Update Prices</button>
        </form>
      )}

      <table>
        <thead>
          <tr>
            <th>Parking_ID</th>
            <th>Type_name</th>
            <th>Price_Hour</th>
            <th>Price_Day</th>
            <th>PStatus_name</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {parkings.length > 0 ? (
            parkings.map((parking) => (
              <tr key={parking.Parking_ID}>
                <td>{parking.Parking_ID}</td>
                <td>{parking.Type_name}</td>
                <td>{parking.Price_Hour}</td>
                <td>{parking.Price_Day}</td>
                <td>{parking.PStatus_name}</td>
                <td>
                  <button onClick={() => handleDelete(parking.Parking_ID)}>Delete</button>
                </td>
              </tr>
            ))
          ) : (
            <tr>
              <td colSpan="6">No data available</td>
            </tr>
          )}
        </tbody>
      </table>
    </div>
  );
}

export default ParkingList;
