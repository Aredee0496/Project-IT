import React from 'react';

function ShuttleData() {
  return <div><h1>ข้อมูลรถรับส่งำะ้ิพหะ้ะกัะพ่้ื่กืเน่กดทื้นทกเ่้ิดแเ้ืิสเทกส่าาาาาาาาาาาาาาาาาาาาาาาาาาาาาาาาาาาาาาาาาาาาาาาาาาาาเกด</h1></div>;
}

export default ShuttleData;
