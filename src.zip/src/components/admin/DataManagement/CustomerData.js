import axios from "axios";
import { useEffect, useState } from "react";
import Modal from "react-modal";
import "./CustomerData.css";

Modal.setAppElement("#root");

const CustomerData = () => {
  const [customers, setCustomers] = useState([]);
  const [cars, setCars] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [customerModalIsOpen, setCustomerModalIsOpen] = useState(false);
  const [carModalIsOpen, setCarModalIsOpen] = useState(false);
  const [editModalIsOpen, setEditModalIsOpen] = useState(false);
  const [newCustomer, setNewCustomer] = useState({
    Customer_Fname: "",
    Customer_Lname: "",
    Customer_Username: "",
    Customer_Password: "",
    Customer_Tel: "",
  });
  const [newCar, setNewCar] = useState({
    Customer_ID: "",
    RegisterPlateNo: "",
  });
  const [editCustomer, setEditCustomer] = useState({
    Customer_ID: "",
    Customer_Fname: "",
    Customer_Lname: "",
    Customer_Tel: "",
  });
  const [searchQuery, setSearchQuery] = useState("");

  useEffect(() => {
    const fetchData = async () => {
      try {
        const customersResponse = await axios.get(
          "http://localhost:5000/api/customers"
        );
        const carsResponse = await axios.get("http://localhost:5000/api/cars");
        setCustomers(customersResponse.data);
        setCars(carsResponse.data);
        setLoading(false);
      } catch (error) {
        console.error("Error fetching data:", error);
        setError(error);
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  const handleDeleteCustomer = (customerId) => {
    const confirmDelete = window.confirm("Are you sure you want to delete this customer?");
    if (confirmDelete) {
      axios
        .delete(`http://localhost:5000/api/customers/${customerId}`)
        .then(() => {
          setCustomers(
            customers.filter((customer) => customer.Customer_ID !== customerId)
          );
          setCars(cars.filter((car) => car.Customer_ID !== customerId));
        })
        .catch((error) => {
          console.error("Error deleting customer:", error);
          setError(error);
        });
    }
  };

  const handleDeleteCar = (carId) => {
    const confirmDelete = window.confirm("Are you sure you want to delete this car?");
    if (confirmDelete) {
      axios
        .delete(`http://localhost:5000/api/cars/${carId}`)
        .then(() => {
          setCars(cars.filter((car) => car.Car_ID !== carId));
        })
        .catch((error) => {
          console.error("Error deleting car:", error);
          setError(error);
        });
    }
  };

  const handleOpenCustomerModal = () => {
    setCustomerModalIsOpen(true);
  };

  const handleCloseCustomerModal = () => {
    setCustomerModalIsOpen(false);
  };

  const handleOpenCarModal = (customerId) => {
    setNewCar((prevState) => ({ ...prevState, Customer_ID: customerId }));
    setCarModalIsOpen(true);
  };

  const handleCloseCarModal = () => {
    setCarModalIsOpen(false);
  };

  const handleOpenEditModal = (customer) => {
    setEditCustomer({
      Customer_ID: customer.Customer_ID,
      Customer_Fname: customer.Customer_Fname,
      Customer_Lname: customer.Customer_Lname,
      Customer_Tel: customer.Customer_Tel,
    });
    setEditModalIsOpen(true);
  };

  const handleCloseEditModal = () => {
    setEditModalIsOpen(false);
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setNewCustomer((prevState) => ({
      ...prevState,
      [name]: value,
    }));
  };

  const handleCarInputChange = (e) => {
    const { name, value } = e.target;
    setNewCar((prevState) => ({
      ...prevState,
      [name]: value,
    }));
  };

  const handleEditInputChange = (e) => {
    const { name, value } = e.target;
    setEditCustomer((prevState) => ({
      ...prevState,
      [name]: value,
    }));
  };

  const handleCustomerSubmit = (e) => {
    e.preventDefault();
    axios
      .post("http://localhost:5000/api/customers", newCustomer)
      .then((response) => {
        setCustomers([
          ...customers,
          { ...newCustomer, Customer_ID: response.data.Customer_ID },
        ]);
        handleCloseCustomerModal();
      })
      .catch((error) => {
        console.error("Error adding customer:", error);
        setError(error);
      });
  };

  const handleCarSubmit = (e) => {
    e.preventDefault();
    axios
      .post("http://localhost:5000/api/cars", {
        Customer_ID: newCar.Customer_ID,
        RegisterPlateNo: newCar.RegisterPlateNo.split(",").map((plate) =>
          plate.trim()
        ),
      })
      .then(() => {
        handleCloseCarModal();
      })
      .catch((error) => {
        console.error("Error adding cars:", error);
        setError(error);
      });
  };

  const handleEditSubmit = (e) => {
    e.preventDefault();
    axios
      .put(`http://localhost:5000/api/customers/${editCustomer.Customer_ID}`, editCustomer)
      .then((response) => {
        setCustomers((prevCustomers) =>
          prevCustomers.map((customer) =>
            customer.Customer_ID === editCustomer.Customer_ID
              ? { ...customer, ...editCustomer }
              : customer
          )
        );
        handleCloseEditModal();
      })
      .catch((error) => {
        console.error("Error updating customer:", error);
        setError(error);
      });
  };

  const filteredCustomers = customers.filter((customer) =>
    customer.Customer_Fname.toLowerCase().includes(searchQuery.toLowerCase()) ||
    customer.Customer_Lname.toLowerCase().includes(searchQuery.toLowerCase()) ||
    customer.Customer_Username.toLowerCase().includes(searchQuery.toLowerCase())
  );

  if (loading) return <p>Loading...</p>;
  if (error) return <p>Error: {error.message}</p>;

  return (
    <div className="table-container">
      <h1>Customer List</h1>
      <input
        type="text"
        placeholder="Search customers..."
        value={searchQuery}
        onChange={(e) => setSearchQuery(e.target.value)}
        className="search-input"
      />
      <button onClick={handleOpenCustomerModal} className="add-customer-button">
        Add Customer
      </button>
      {filteredCustomers.length > 0 ? (
        <table>
          <thead>
            <tr>
              <th>ID</th>
              <th>First Name</th>
              <th>Last Name</th>
              <th>Username</th>
              <th>Telephone</th>
              <th>Register Plate Numbers</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {filteredCustomers.map((customer) => (
              <tr key={customer.Customer_ID}>
                <td>{customer.Customer_ID}</td>
                <td>{customer.Customer_Fname}</td>
                <td>{customer.Customer_Lname}</td>
                <td>{customer.Customer_Username}</td>
                <td>{customer.Customer_Tel}</td>
                <td>
                  <table>
                    <tbody>
                      {cars
                        .filter((car) => car.Customer_ID === customer.Customer_ID)
                        .map((car) => (
                          <tr key={car.Car_ID}>
                            <td>{car.RegisterPlateNo}</td>
                            <td>
                              <button onClick={() => handleDeleteCar(car.Car_ID)}>
                                Delete
                              </button>
                            </td>
                          </tr>
                        ))}
                    </tbody>
                  </table>
                </td>
                <td>
                  <button onClick={() => handleOpenCarModal(customer.Customer_ID)}>
                    Add Cars
                  </button>
                  <button onClick={() => handleOpenEditModal(customer)}>
                    Edit
                  </button>
                  <button onClick={() => handleDeleteCustomer(customer.Customer_ID)}>
                    Delete
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      ) : (
        <p>No customers found.</p>
      )}

      {/* Add Customer Modal */}
      <Modal
        isOpen={customerModalIsOpen}
        onRequestClose={handleCloseCustomerModal}
        contentLabel="Add Customer"
        className="modal"
        overlayClassName="overlay"
      >
        <h2>Add New Customer</h2>
        <form onSubmit={handleCustomerSubmit}>
          <label>
            First Name:
            <input
              type="text"
              name="Customer_Fname"
              value={newCustomer.Customer_Fname}
              onChange={handleInputChange}
              required
            />
          </label>
          <label>
            Last Name:
            <input
              type="text"
              name="Customer_Lname"
              value={newCustomer.Customer_Lname}
              onChange={handleInputChange}
              required
            />
          </label>
          <label>
            Username:
            <input
              type="text"
              name="Customer_Username"
              value={newCustomer.Customer_Username}
              onChange={handleInputChange}
              required
            />
          </label>
          <label>
            Password:
            <input
              type="password"
              name="Customer_Password"
              value={newCustomer.Customer_Password}
              onChange={handleInputChange}
              required
            />
          </label>
          <label>
            Telephone:
            <input
              type="text"
              name="Customer_Tel"
              value={newCustomer.Customer_Tel}
              onChange={handleInputChange}
              required
            />
          </label>
          <button type="submit">Add Customer</button>
          <button onClick={handleCloseCustomerModal}>Cancel</button>
        </form>
      </Modal>

      {/* Add Car Modal */}
      <Modal
        isOpen={carModalIsOpen}
        onRequestClose={handleCloseCarModal}
        contentLabel="Add Car"
        className="modal"
        overlayClassName="overlay"
      >
        <h2>Add Car</h2>
        <form onSubmit={handleCarSubmit}>
          <label>
            Register Plate Numbers (comma separated):
            <input
              type="text"
              name="RegisterPlateNo"
              value={newCar.RegisterPlateNo}
              onChange={handleCarInputChange}
              required
            />
          </label>
          <button type="submit">Add Car</button>
          <button onClick={handleCloseCarModal}>Cancel</button>
        </form>
      </Modal>

      {/* Edit Customer Modal */}
      <Modal
        isOpen={editModalIsOpen}
        onRequestClose={handleCloseEditModal}
        contentLabel="Edit Customer"
        className="modal"
        overlayClassName="overlay"
      >
        <h2>Edit Customer</h2>
        <form onSubmit={handleEditSubmit}>
          <label>
            First Name:
            <input
              type="text"
              name="Customer_Fname"
              value={editCustomer.Customer_Fname}
              onChange={handleEditInputChange}
              required
            />
          </label>
          <label>
            Last Name:
            <input
              type="text"
              name="Customer_Lname"
              value={editCustomer.Customer_Lname}
              onChange={handleEditInputChange}
              required
            />
          </label>
          <label>
            Telephone:
            <input
              type="text"
              name="Customer_Tel"
              value={editCustomer.Customer_Tel}
              onChange={handleEditInputChange}
              required
            />
          </label>
          <button type="submit">Update Customer</button>
          <button onClick={handleCloseEditModal}>Cancel</button>
        </form>
      </Modal>
    </div>
  );
};

export default CustomerData;
