import React from 'react';

function Bookings() {
  return <div><h1>หน้าการจอง</h1></div>;
}

export default Bookings;