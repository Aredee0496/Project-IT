import React from 'react';

function Reports() {
  return <div><h1>หน้ารายงาน</h1></div>;
}

export default Reports;