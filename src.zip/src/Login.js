import React, { useState } from "react";
import { useAuth } from "./context/AuthContext";
import { useNavigate, Link } from "react-router-dom";
import "./Login.css";

const Login = () => {
  const [user, setUser] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState(null);
  const { login } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();

    const Useremployee = "admin";
    const UserpasswordEmployee = "admin";
    const Usercustomer = "customer";
    const UserpasswordCustomer = "customer";

    if (user === Useremployee && password === UserpasswordEmployee) {
      const userData = {
        username: user,
        role: "employee",
      };

      login(userData);
      navigate("/");
    } else if (user === Usercustomer && password === UserpasswordCustomer) {
      const userData = {
        username: user,
        role: "customer",
      };

      login(userData);
      navigate("/");
    } else {
      setError("Username หรือ Password ไม่ถูกต้อง! กรุณาลองใหม่อีกครั้ง");
    }
  };

  return (
    <div className="main-login">
      <div className="login">
        <form onSubmit={handleSubmit}>
          <div>
            <label>Username:</label>
            <input
              type="user"
              value={user}
              onChange={(e) => setUser(e.target.value)}
            />
          </div>
          <div>
            <label>Password:</label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
          </div>
          {error && <div className="error">{error}</div>}
          <button type="submit">Login</button>
        </form>
        <div>
          <p>
            หากยังไม่ได้สมัครสมาชิก? <Link to="/register">สมัครสมาชิก</Link>
          </p>
        </div>
      </div>
    </div>
  );
};

export default Login;
