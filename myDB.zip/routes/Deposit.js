const express = require('express');
const router = express.Router();
const DepositController = require('../controllers/Deposit');

router.get('/deposits', DepositController.getAll);
router.get('/deposits/:id', DepositController.getById);
router.post('/deposits', DepositController.create);
router.put('/deposits/:id', DepositController.update);
router.delete('/deposits/:id', DepositController.delete);

module.exports = router;
