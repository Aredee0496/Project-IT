const express = require('express');
const router = express.Router();
const authController = require('../controllers/auth'); // ตรวจสอบการนำเข้าคอนโทรลเลอร์

router.post('/login', authController.login); // เส้นทาง POST สำหรับการเข้าสู่ระบบ

module.exports = router;
