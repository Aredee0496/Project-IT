const db = require('../db'); // เชื่อมต่อฐานข้อมูล

const login = (req, res) => {
  const { username, password } = req.body;

  // ตรวจสอบในตาราง officer
  const officerQuery = "SELECT * FROM officer WHERE Officer_Username = ?";
  db.query(officerQuery, [username], (err, results) => {
    if (err) {
      return res.status(500).json({ success: false, message: "ข้อผิดพลาดในการทำงานกับฐานข้อมูล" });
    }

    if (results.length > 0) {
      const officer = results[0];
      // ตรวจสอบรหัสผ่านที่ตรงตัว
      if (password === officer.Officer_Password) {
        return res.json({ success: true, username: username, role: "employee" });
      } else {
        return res.json({ success: false, message: "ชื่อผู้ใช้หรือรหัสผ่านไม่ถูกต้อง" });
      }
    }

    // ตรวจสอบในตาราง customer
    const customerQuery = "SELECT * FROM customer WHERE Customer_Username = ?";
    db.query(customerQuery, [username], (err, results) => {
      if (err) {
        return res.status(500).json({ success: false, message: "ข้อผิดพลาดในการทำงานกับฐานข้อมูล" });
      }

      if (results.length > 0) {
        const customer = results[0];
        // ตรวจสอบรหัสผ่านที่ตรงตัว
        if (password === customer.Customer_Password) {
          return res.json({ success: true, username: username, role: "customer" });
        } else {
          return res.json({ success: false, message: "ชื่อผู้ใช้หรือรหัสผ่านไม่ถูกต้อง" });
        }
      } else {
        return res.json({ success: false, message: "ชื่อผู้ใช้หรือรหัสผ่านไม่ถูกต้อง" });
      }
    });
  });
};

module.exports = {
  login
};
