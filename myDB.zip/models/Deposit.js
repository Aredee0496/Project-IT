const db = require('../db');

const Deposit = {
  getAll: (callback) => {
    db.query('SELECT * FROM deposit', (err, results) => {
      if (err) {
        return callback(err, null);
      }
      callback(null, results);
    });
  },

  getById: (id, callback) => {
    db.query('SELECT * FROM deposit WHERE Deposit_ID = ?', [id], (err, results) => {
      if (err) {
        return callback(err, null);
      }
      callback(null, results[0]);
    });
  },

  create: (data, callback) => {

    db.query('SELECT Deposit_ID FROM deposit ORDER BY Deposit_ID DESC LIMIT 1', (err, results) => {
      if (err) {
        return callback(err, null);
      }
  
      let newId;
      if (results.length > 0) {
        const lastId = results[0].Deposit_ID;
        const lastNumber = parseInt(lastId.replace('DEP-', '')); 
  
        if (lastNumber >= 9999) {
          newId = `DEP-${lastNumber + 1}`;
        } else {
          newId = `DEP-${String(lastNumber + 1).padStart(4, '0')}`; 
        }
      } else {
        newId = 'DEP-0001'; 
      }
  

      data.Deposit_ID = newId; 
      db.query('INSERT INTO deposit SET ?', data, (err, results) => {
        if (err) {
          return callback(err, null);
        }
        callback(null, results.insertId);
      });
    });
  },
  

  update: (id, data, callback) => {
    db.query('UPDATE deposit SET ? WHERE Deposit_ID = ?', [data, id], (err, results) => {
      if (err) {
        return callback(err, null);
      }
      callback(null, results);
    });
  },

  delete: (id, callback) => {
    db.query('DELETE FROM deposit WHERE Deposit_ID = ?', [id], (err, results) => {
      if (err) {
        return callback(err, null);
      }
      callback(null, results);
    });
  }
};

module.exports = Deposit;
